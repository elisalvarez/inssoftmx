import {
    IsAlphanumeric,
    IsEmail,
    IsNotEmpty,
    IsString,
    Matches,
    MinLength,
    IsOptional,
  } from 'class-validator';
  
 const passwordRegEx =
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*d)(?=.*[@$!%*?&])[A-Za-zd@$!%*?&]{8,20}$/;

export class CreateUserDto {
    @IsString()
    @MinLength(3, { message: 'El nombre debe tener al menos 3 caracteres.'})
    @IsNotEmpty()
    name: string;
  
    @IsNotEmpty()
    @MinLength(5, { message: 'El nombre de usuario debe tener al menos 5 caracteres.'})
    @IsAlphanumeric(null, {
      message: 'El nombre de usuario solo puede contener letras y números.',
    })
    username: string;
  
    @IsNotEmpty()
    @IsEmail(null, { message: 'Introduce una dirección de correo electrónico válida.' })
    email: string;
  
    @IsNotEmpty()
    @Matches(passwordRegEx, {
      message: `Password must contain Minimum 8 and maximum 20 characters, 
      at least one uppercase letter, 
      one lowercase letter, 
      one number and 
      one special character`,
    })
    password: string;

    @IsString()
    @Matches(/^\+?[1-9]\d{1,14}$/, {
        message: 'El número de teléfono debe ser un formato válido.',
    })
    phoneNumber: string;

    @IsOptional()
    @IsString()
    @Matches(/^\+\d{1,3}$/, {
        message: 'El código de país debe ser un formato válido.',
    })
    countryCode?: string;
}
